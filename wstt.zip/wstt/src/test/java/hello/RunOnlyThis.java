package hello;

public interface RunOnlyThis {

}
