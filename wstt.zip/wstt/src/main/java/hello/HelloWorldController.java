package hello;

import java.util.concurrent.atomic.AtomicLong;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
//@RequestMapping("/hello-world")
public class HelloWorldController {

    private static final String template = "Hello, %s!";
    private final AtomicLong counter = new AtomicLong();

    @RequestMapping(value = "/hello-world", method=RequestMethod.GET)
    public @ResponseBody Greeting sayHello(@RequestParam(value="name", required=false, defaultValue="Stranger") String name) {
    	for(int i=1;i<6;i++) {
    		try {
				Thread.sleep(1000L);
			} catch (InterruptedException e) {
				System.out.println("Stranger thread id= "+Thread.currentThread().getId()+" interrupted");
			}
    		System.out.println("Stranger thread id= "+Thread.currentThread().getId()+" - i= "+i);
    	}
        return new Greeting(counter.incrementAndGet(), String.format(template, name));
    }
    @RequestMapping(value = "/bye-world", method=RequestMethod.GET)
    public @ResponseBody Greeting sayBye(@RequestParam(value="name", required=false, defaultValue="GoodBye") String name) {
    	for(int i=1;i<6;i++) {
    		try {
				Thread.sleep(500L);
			} catch (InterruptedException e) {
				System.out.println("GoodBye thread id= "+Thread.currentThread().getId()+" interrupted");
			}
    		System.out.println("GoodBye thread id= "+Thread.currentThread().getId()+" - i= "+i);
    	}
        return new Greeting(counter.incrementAndGet(), String.format(template, name));
    }

}
